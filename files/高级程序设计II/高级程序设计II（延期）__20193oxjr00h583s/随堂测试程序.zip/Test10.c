extern void *memset(void *_s, int _c, unsigned long _n);
extern void *memcpy(void *dst, const void *src, unsigned long _n);
extern void *malloc(unsigned long _n);
extern void free(void* ptr);
extern char *strcpy(char* dst, const char *src);
extern void foo(void *ptr);
extern int  bar(void *ptr);

struct ADev {
	int id;
	char name[8];
	int status;
};

struct BDev {
	int id;
	int status;
};

struct CDev{
	struct BDev dev;
	char name[8];
};

struct DDev {
	struct ADev dev;
	int pid;
};


char* Test10_func1(unsigned int memsize) {
	char* mem = (char*)malloc(memsize);
	if (!mem) return (char*)0;
	memset(mem, 0, memsize);
	return mem;
}

struct ADev* Test10_func2() {
	struct ADev* mem = (struct ADev*)malloc(sizeof(struct ADev));
	if (!mem) return (struct ADev*)0;
	memset(mem, 0, sizeof(struct ADev));
	return mem;
}

struct ADev* Test10_func3() {
	struct ADev* mem = (struct ADev*)malloc(sizeof(struct ADev));
	// if (!mem) return (char*)0;
	memset(mem, 0, sizeof(struct ADev));
	return mem;
}

struct ADev* Test10_func4() {
	struct ADev* mem = (struct ADev*)malloc(sizeof(struct ADev));
	if (!mem) return (struct ADev*)0;
	memset(mem, 0, sizeof(struct ADev));
	static int _id = 0;
	mem->id = _id++;
	if (mem->id % 3 == 0) {
		memcpy(mem->name, "master", sizeof("master"));
	} else {
		memcpy(mem->name, "slave", sizeof("slave"));
	}
	return mem;
}

struct BDev* Test10_func5() {
	struct BDev* mem = (struct BDev*)malloc(sizeof(struct BDev));
	if (!mem) return (struct BDev*)0;
	static int _id = 0;
	mem->id = _id++;
	int status;
	if (mem->id % 5 == 0) {
		status = 12;
		memcpy(&mem->status, &status, sizeof(int));
	} else {
		status = 9;
		memcpy(&mem->status, &status, sizeof(int));
	}
	return mem;
}

struct BDev* Test10_func6() {
	struct BDev* mem = (struct BDev*)malloc(sizeof(struct BDev));
	if (!mem) return (struct BDev*)0;
	static int _id = 0;
	mem->id = _id++;
	if (mem->id % 3 == 0) {
		int status = 17;
		memcpy(&mem->status, &status, sizeof(int));
	}
	return mem;
}

struct CDev* Test10_func7() {
	struct CDev* mem = (struct CDev*)malloc(sizeof(struct CDev));
	if (!mem) return (struct CDev*)0;
	memset(mem, 0, sizeof(struct CDev));
	static int _id = 0;
	mem->dev.id = _id++;
	memcpy(mem->name, "c-dev", sizeof("c-dev"));
	foo(mem);
	if (!mem->dev.status) {
		free(mem);
		return (struct CDev*)0;
	}
	return mem;
}

struct CDev* Test10_func8() {
	struct CDev* mem = (struct CDev*)malloc(sizeof(struct CDev));
	if (!mem) return (struct CDev*)0;
	memset(mem, 0, sizeof(struct CDev));
	static int _id = 0;
	mem->dev.id = _id++;
	memcpy(mem->name, "c-dev", sizeof("c-dev"));
	foo(mem);
	if (!mem->dev.status) {
		free(mem);
	}
	return mem;
}

void Test10_func9() {
	struct CDev* mem = (struct CDev*)malloc(sizeof(struct CDev));
	if (!mem) return ;
	memset(mem, 0, sizeof(struct CDev));
	static int _id = 0;
	mem->dev.id = _id++;
	memcpy(mem->name, "c-dev", sizeof("c-dev"));
	foo(mem);
	if (!mem->dev.status) {
		free(mem);
	}
}

void Test10_func10(int pid) {
	struct DDev* mem = (struct DDev*)malloc(sizeof(struct DDev));
	if (!mem) return ;
	memset(mem, 0, sizeof(struct DDev));
	static int _id = 0;
	mem->dev.id = _id++;
	memcpy(mem->dev.name, "d-dev", sizeof("d-dev"));
	foo(mem);
	if (!mem->dev.status && mem->pid < 0) {
		free(mem);
	}
}

void Test10_func11(int pid) {
	struct DDev* mem = (struct DDev*)malloc(sizeof(struct DDev));
	if (!mem) return;
	memset(mem, 0, sizeof(struct DDev));
	static int _id = 0;
	mem->dev.id = _id++;
	memcpy(mem->dev.name, "d-dev", sizeof("d-dev"));
	foo(mem);
	if (!mem->dev.status && mem->pid < 0) {
		free(mem);
	}
}

void TEst10_func12(struct ADev *dev) {
	if (bar(dev)) {
		free(dev);
	}
}

void TEst10_func13(struct BDev *dev) {
	if (bar(dev)) {
		free(dev);
	}
}

void TEst10_func14(struct CDev *dev) {
	if (bar(dev)) {
		free(dev);
	}
}

void TEst10_func15(struct DDev *dev) {
	if (bar(dev)) {
		free(dev);
	}
}

void TEst10_func16(char *str) {
	free(str);
}