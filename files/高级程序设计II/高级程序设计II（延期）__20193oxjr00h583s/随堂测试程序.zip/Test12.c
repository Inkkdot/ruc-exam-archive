extern int xfunc(int);
extern int yfunc();
extern int test(int, int);
extern int foo(int);
extern int bar(int);
extern void record(int);

int Test12_0(int param1, short param2) {
	int local1, local2, ret;
	if (param1 > 10) {
		local1 = param1 * param2;
		switch (local1) {
			case 3:
				local2 = xfunc(param2);
				break;
			case 5:
				local2 = yfunc();
				break;
			default:
				local2 = local1 % 7;
		}
	} else if (param2 > 0) {
		local2 = (param2 << 3) / 11;
	}
	if (test(local1, local2)) {
		ret = foo(local1);
	} else {
		ret = bar(local2);
	}
	return ret;
}

int Test12_1(int param) {
	int local;
	if (param >= 99) {
		local = xfunc(param) - yfunc();
	} else {
		local = (param * 3) >> 3;
	}
	int ret = bar(local);
	return ret;
}

int Test12_2(int param1, short param2) {
	int local1 = param1 - param2;
	int local2 = param2 - param1;
	int ret;
	if (test(local1, local2)) {
		local1 = xfunc(param1 & 0xFF);
	} else {
		for (; local1 >= local2; local1--) {
			local2 += foo(local2);
		}
		local1 = local2;
	}
	return bar(local1);
}

void Test12_3(int param) {
	int local;
	if (param >= 99) {
		local = xfunc(param);
	} else {
		local = (param * 3) >> 3;
	}
	bar(local);
}

void Test12_4(int param) {
	int local;
	if (param >= 99) {
		local = xfunc(param);
	} else {
		local = yfunc();
	}
	bar(local);
}

void Test12_5(int param) {
	int local;
	if (param >= 99) {
		local = xfunc(param) - yfunc();
	} else {
		local = (param * 3) >> 3;
	}
	bar(local);
}

void Test12_6(int param1, short param2) {
	int local1, local2;
	if (param1 > 10) {
		local1 = param1 * param2;
		switch (local1) {
			case 13:
				local2 = xfunc(param2);
				break;
			default:
				local2 = local1 % 17;
		}
	} else {
		local2 = param2 | 0xABCDEF;
	}
	if (test(local1, local2)) {
		record(bar(local1));
	}
}

void Test12_7(int param) {
	if ((param % 99) / 3 > 9) {
		bar(xfunc(param));
	}
}

void Test12_8(int param1, int param2) {
	int local = 0;
	while (param1 < param2) {
		local += param2;
		param1++;
	}
	xfunc(param1);
	bar(local);
}

void Test12_9(int param1, int param2, int param3) {
	int local = param1 * param2;
	if (local > 0xFF00CC) {
		local = local % param3;
		switch (local) {
			case 3: 
				local = xfunc(param3);
				break;
			case 5:
				local = xfunc(param2);
				break;
			default:
				local = yfunc();
		}
	} else {
		local = param2 / param3;
	}
	bar(local);
}

int Test12_10(int param) {
	int l = xfunc(param);
	if (l < 10)
		return foo(l);
	else
		return bar(l * 3);
}